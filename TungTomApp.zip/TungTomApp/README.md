# TrollModPoke 2.1 — menu nổi + userscript cho Via

- **App (APK):** nút 🍤 nổi + menu hiện đè lên mọi ứng dụng, chạy nền (foreground service).
- **Userscript (`userscript/TrollModPoke.user.js`):** một file JS duy nhất, cài vào Via. Nó chứa bot + giảm lag + kênh liên lạc với app.
- Hai bên nói chuyện qua cổng cục bộ `127.0.0.1:38765`, bảo vệ bằng "mã kết nối" ngẫu nhiên riêng của máy.

## 1. Đưa userscript lên GitHub
1. Tạo repo GitHub (public), upload file `userscript/TrollModPoke.user.js` (để ở thư mục gốc của repo cho link ngắn).
2. Mở file đó trên GitHub → nút **Raw** → copy link, dạng `https://raw.githubusercontent.com/<tên>/<repo>/main/TrollModPoke.user.js`.

## 2. Cài vào Via
Mở link Raw trong Via. Nếu Via hỏi cài script thì xác nhận. Nếu không, mở file ở trang Raw, chọn tất cả, sao chép,
rồi vào phần quản lý script của Via, thêm script mới và dán vào. Đảm bảo script đang bật.

## 3. Kết nối
1. Mở app, cấp quyền "hiển thị trên ứng dụng khác" → menu nổi tự bật.
2. Bấm **Sao chép mã kết nối** (màn hình chính của app, hoặc menu 🍤 → ⚙ Cài đặt).
3. Mở pokesurvivor.com trong Via, khi script hỏi thì dán mã (chỉ hỏi 1 lần, mã được lưu trong trang).
4. Viền nút 🍤 xanh lá = đã kết nối.

## Sửa script
Sửa `bridge.js`, `TungTom_user.js`, `comm.js` trong `userscript/` rồi chạy `python3 build.py` để sinh lại `TrollModPoke.user.js`.

## Build APK
GitHub Actions: upload cả thư mục (giữ `.github/`) → *Actions* → *Build APK* → tải artifact `TungTom-apk`.

Gốc bot: damhieu2808/PokeSurvivorTool (MIT).
