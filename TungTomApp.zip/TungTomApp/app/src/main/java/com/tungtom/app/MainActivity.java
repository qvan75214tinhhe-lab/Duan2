package com.tungtom.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Màn hình cài đặt ban đầu: cấp quyền, bật/tắt menu nổi, sao chép link kết nối trình duyệt. */
public class MainActivity extends Activity {
    private TextView status;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            refresh();
            h.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = dp(16);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad, pad, pad);
        col.setBackgroundColor(0xFF141A22);

        TextView t = new TextView(this);
        t.setText("TrollModPoke");
        t.setTextColor(0xFF8FB4FF);
        t.setTextSize(22);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(t);

        status = new TextView(this);
        status.setTextColor(0xFFE6EBF2);
        status.setTextSize(14);
        status.setPadding(0, dp(8), 0, dp(8));
        col.addView(status);

        col.addView(btn("1) Cấp quyền hiển thị trên ứng dụng khác", v -> requestOverlay()));
        col.addView(btn("2) ▶ Bật menu nổi (chạy nền)", v -> startMenu()));
        col.addView(btn("■ Tắt menu nổi", v -> stopService(new Intent(this, OverlayService.class))));
        col.addView(btn("🌐 Mở pokesurvivor.com", v -> openUrl("https://pokesurvivor.com/")));
        col.addView(btn("Sao chép mã kết nối", v -> copy("mã kết nối", Cfg.token(this))));

        TextView help = new TextView(this);
        help.setTextColor(0xFFB9C3D0);
        help.setTextSize(13);
        help.setPadding(0, dp(12), 0, 0);
        help.setText("Cách dùng\n"
                + "1. Bật menu nổi: nút 🍤 xuất hiện trên mọi ứng dụng (kéo được). Viền xanh lá = đã kết nối trang game.\n\n"
                + "2. Cài file TrollModPoke.user.js vào trình duyệt Via (xem README).\n\n"
                + "3. Bấm \"Sao chép mã kết nối\", mở pokesurvivor.com trong Via, khi script hỏi thì dán mã vào (chỉ hỏi 1 lần).\n\n"
                + "• Nếu Via hoặc trình duyệt hiện hộp thoại hỏi quyền truy cập mạng cục bộ, hãy chọn Cho phép.");
        col.addView(help);

        ScrollView sv = new ScrollView(this);
        sv.addView(col);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Settings.canDrawOverlays(this) && !OverlayService.running) startMenu();
        h.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
    }

    private void refresh() {
        LocalServer s = LocalServer.current;
        String host = s == null ? null : s.activeHost();
        status.setText("Quyền hiển thị trên ứng dụng khác: " + (Settings.canDrawOverlays(this) ? "đã cấp ✓" : "chưa cấp ✗")
                + "\nMenu nổi: " + (OverlayService.running ? "đang chạy ✓" : "đang tắt")
                + "\nTrang game: " + (host != null && !host.isEmpty() ? "đã kết nối (" + host + ") ✓" : "chưa kết nối"));
    }

    private void requestOverlay() {
        if (Settings.canDrawOverlays(this)) { toast("Đã có quyền rồi"); return; }
        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
    }

    private void startMenu() {
        if (!Settings.canDrawOverlays(this)) { requestOverlay(); return; }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        startForegroundService(new Intent(this, OverlayService.class));
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            toast("Không mở được trình duyệt");
        }
    }

    private void copy(String label, String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText(label, text));
        toast("Đã sao chép");
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Button btn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(0xFFE6EBF2);
        b.setTextSize(14);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF1D2530);
        g.setCornerRadius(dp(8));
        g.setStroke(dp(1), 0xFF3A4553);
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.setMargins(0, dp(4), 0, dp(4));
        b.setLayoutParams(lp);
        return b;
    }
}
