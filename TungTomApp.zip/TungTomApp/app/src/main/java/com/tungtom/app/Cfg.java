package com.tungtom.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.SecureRandom;

/** Mã kết nối (token) ngẫu nhiên riêng cho máy này. Userscript trong trình duyệt phải có mã này mới nói chuyện được với app. */
final class Cfg {
    private Cfg() {}

    static String token(Context c) {
        SharedPreferences p = c.getSharedPreferences("tt", Context.MODE_PRIVATE);
        String t = p.getString("token", null);
        if (t == null || t.length() != 32) {
            byte[] b = new byte[16];
            new SecureRandom().nextBytes(b);
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x & 0xff));
            t = sb.toString();
            p.edit().putString("token", t).apply();
        }
        return t;
    }
}
