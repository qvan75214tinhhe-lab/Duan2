#!/usr/bin/env python3
"""Ghép bridge.js + TungTom_user.js + comm.js thành MỘT file TrollModPoke.user.js để đưa lên GitHub / cài vào Via."""
import re
rd = lambda f: open(f, encoding="utf-8").read()
HEADER = """// ==UserScript==
// @name         TrollModPoke (kết nối app)
// @namespace    com.tungtom.app
// @version      2.1.0
// @description  Bot + giảm lag cho pokesurvivor.com, kết nối với menu nổi của app TrollModPoke
// @match        https://pokesurvivor.com/*
// @match        https://www.pokesurvivor.com/*
// @match        https://pokesurvivor.doofcraft.com/*
// @run-at       document-start
// @grant        none
// @inject-into  page
// ==/UserScript==
"""
bot = re.sub(r"\A// ==UserScript==.*?// ==/UserScript==\n", "", rd("TungTom_user.js"), flags=re.S)
pre = "window.__TT_HIDE=true;window.__TT_OPT={};window.__TT_MINI={};\n"
body = pre + rd("bridge.js") + "\n" + bot + "\n" + rd("comm.js") + "\n"
# bot.js có sẵn các dòng comment giống header userscript; đổi nhẹ để trình duyệt không nhầm là header thứ hai
body = body.replace("// ==UserScript==", "// == UserScript ==").replace("// ==/UserScript==", "// == /UserScript ==")
open("TrollModPoke.user.js", "w", encoding="utf-8").write(HEADER + body)
print("OK -> TrollModPoke.user.js")
