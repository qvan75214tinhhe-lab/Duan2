// Kênh liên lạc trang game <-> app (menu nổi). Chạy SAU bridge.js và userscript.
// Trang hỏi app theo kiểu long-poll tới 127.0.0.1; app gửi lệnh, trang chạy rồi trả kết quả.
// Chỉ nhận lệnh gọi hàm trong danh sách trắng (PSBot / PSLite / __TT) nên không cần eval (không vướng CSP).
(function () {
  if (window.__TT_COMM) return;
  if (!/^(www\.)?pokesurvivor\.com$|^pokesurvivor\.doofcraft\.com$/.test(location.hostname)) return;
  if (window.top !== window) return;
  window.__TT_COMM = true;

  var base = 'http://127.0.0.1:38765', tk = '', dead = false;
  var pid = Math.random().toString(36).slice(2) + Date.now().toString(36);
  var hello = true;
  var ALLOW = /^(PSBot|PSLite|__TT)(\.[A-Za-z_$][\w$]*)*$/;
  var BAD = /(^|\.)(__proto__|constructor|prototype)(\.|$)/;

  function url(p, extra) { return base + p + '?t=' + tk + '&pid=' + pid + (extra || ''); }
  function vis() { return document.visibilityState === 'visible' ? 1 : 0; }
  function clean(v) {
    if (v === undefined) return null;
    try { return JSON.parse(JSON.stringify(v)); } catch (e) { return String(v); }
  }

  function resolve(path) {
    if (typeof path !== 'string' || !ALLOW.test(path) || BAD.test(path)) throw new Error('đường dẫn không hợp lệ');
    var p = path.split('.'), o = window;
    for (var i = 0; i < p.length - 1; i++) {
      o = o[p[i]];
      if (o == null) throw new Error('chưa có ' + p.slice(0, i + 1).join('.'));
    }
    return { o: o, k: p[p.length - 1] };
  }

  function state() {
    var o = { host: location.hostname };
    if (window.PSLite) o.lite = PSLite.get();
    if (window.PSBot) { var s = PSBot.state; o.bot = { on: !!s.on, done: s.done, target: s.target, debug: !!s.debug }; }
    try { o.run = JSON.parse(localStorage.getItem('psbot.dcRun') || '{}'); } catch (e) { o.run = {}; }
    return o;
  }

  function exec(c) {
    var r;
    switch (c.op) {
      case 'call':
        r = resolve(c.path);
        if (typeof r.o[r.k] !== 'function') throw new Error('không phải hàm: ' + c.path);
        return r.o[r.k].apply(r.o, c.args || []);
      case 'get':
        r = resolve(c.path);
        return r.o[r.k];
      case 'set':
        r = resolve(c.path);
        r.o[r.k] = c.val;
        return true;
      case 'state':
        return state();
      case 'run':
        if (!/^[a-zA-Z]+$/.test(c.key || '')) throw new Error('key');
        var k = 'psbot.dcRun', o = {};
        try { o = JSON.parse(localStorage.getItem(k) || '{}'); } catch (e) { o = {}; }
        o[c.key] = String(c.val);
        localStorage.setItem(k, JSON.stringify(o));
        return true;
      case 'reload':
        setTimeout(function () { location.reload(); }, 150);
        return true;
    }
    throw new Error('lệnh lạ');
  }

  function report(id, body) {
    body.id = id;
    fetch(url('/result'), { method: 'POST', body: JSON.stringify(body), headers: { 'Content-Type': 'text/plain' } }).catch(function () {});
  }

  function run(c) {
    Promise.resolve().then(function () { return exec(c); }).then(
      function (v) { report(c.id, { v: clean(v) }); },
      function (e) { report(c.id, { err: String((e && e.message) || e) }); }
    );
  }

  function loop() {
    var extra = '&host=' + encodeURIComponent(location.hostname) + '&vis=' + vis() + (hello ? '&hello=1' : '');
    hello = false;
    fetch(url('/poll', extra), { cache: 'no-store' })
      .then(function (r) {
        if (r.status === 403) { dead = true; try { localStorage.removeItem('tt_token'); } catch (e) {} throw new Error('sai mã'); }
        if (!r.ok) throw new Error('http ' + r.status);
        return r.json();
      })
      .then(function (c) { if (c && c.id) run(c); setTimeout(loop, 0); })
      .catch(function () { if (dead) return; hello = true; setTimeout(loop, 3000); });
  }

  document.addEventListener('visibilitychange', function () {
    fetch(url('/vis', '&vis=' + vis()), { method: 'POST', body: '', headers: { 'Content-Type': 'text/plain' } }).catch(function () {});
  });

  // Mã kết nối: app → menu 🍤 → Cài đặt → "Sao chép mã kết nối". Chỉ hỏi 1 lần, lưu lại trong trang.
  function start() {
    var t = '';
    try { t = localStorage.getItem('tt_token') || ''; } catch (e) {}
    if (!/^[0-9a-f]{32}$/i.test(t)) {
      t = String(window.prompt('TrollModPoke: dán "mã kết nối" từ app (menu 🍤 > Cài đặt > Sao chép mã kết nối)') || '').trim();
      if (!/^[0-9a-f]{32}$/i.test(t)) return;
      try { localStorage.setItem('tt_token', t); } catch (e) {}
    }
    tk = encodeURIComponent(t);
    loop();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
